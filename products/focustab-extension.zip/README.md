# FocusTab — Productive New Tab Dashboard

Replace your Chrome new tab page with a beautiful productivity dashboard.

## Features
- ⏱ **Focus Timer** — Pomodoro-style timer with customizable durations
- ✅ **Task Manager** — Daily to-do list with completion tracking
- 📝 **Quick Notes** — Instant notepad that auto-saves
- 🔗 **Quick Links** — Fast access to your favorite sites
- 💡 **Daily Motivation** — Inspirational quotes that change daily
- 🔥 **Streak Tracker** — Build a daily habit streak
- 📊 **Focus Stats** — Track your productive time

## Install
1. Download or clone this repo
2. Open `chrome://extensions` in Chrome
3. Enable "Developer mode"
4. Click "Load unpacked" and select this folder
5. Open a new tab — enjoy!

## Privacy
All data stored locally in your browser. Nothing is sent to any server.
